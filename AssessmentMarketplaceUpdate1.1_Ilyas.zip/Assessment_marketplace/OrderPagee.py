from flask import Flask, render_template , url_for, flash, redirect, session, Blueprint
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, RadioField
from wtforms.validators import DataRequired, Length, EqualTo, InputRequired
from flask_sqlalchemy import SQLAlchemy


#Configuration
bp = Flask (__name__)
bp.config['SECRET_KEY'] = 'hi'
#db = SQLAlchemy(bp)
#bp = Blueprint( __name__) # Code doesn't wrk


#app=Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///items.sqlite'
#db.init_app(app)




#Class
class orderforum(FlaskForm):
    fullname = StringField('Fullname',validators=[InputRequired()])
    address = StringField('Address',validators=[InputRequired()])
    postcode = StringField('Postcode', validators=[InputRequired(),Length(max=4)])
    submit = SubmitField('Confirm and Pay')


#Route
@bp.route("/OrderPage", methods=['GET', 'POST'])
def orderr():
    form = orderforum()
    if form.validate_on_submit():
        flash('Successful Purchase! Order id: #35093783', 'success')
        return redirect(url_for('order'))
    return render_template("order.html", form=form)



#Model
'''
class Item(db.Model):
    __tablename__ = 'ProducT'
    fullname = db.Column(db.String(50))
    address = db.Column(db.String(50))
    postcode = db.Column(db.Integer(50))


    def __repr__(self):
        return '<Item: fullname=%r, address=%r, postcode=%r>' %.format(self.fullname, self.address, self.postcode)
'''

#Debugging 
if __name__ == "__main__":
    bp.run(debug=True)
