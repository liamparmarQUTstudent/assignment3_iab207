from flask import Flask, render_template , url_for, flash, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length
from flask_sqlalchemy import SQLAlchemy


#Configuration
bp = Flask (__name__)
bp.config['SECRET_KEY'] = 'hi'
#db = SQLAlchemy(bp)

#app=Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///items.sqlite'
#db.init_app(app)



#Class
class createproduct(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    amount = StringField('Amount',validators=[DataRequired(), Length(max=10)])
    description = StringField('Description', validators=[DataRequired()])
    length = StringField('Length', validators=[DataRequired()])
    material = StringField('Material', validators=[DataRequired()])
    gender = SelectField('Gender', choices = [ ('cpp', 'Select'), ('cpp', 'New'), ('cpp', 'Used'), ('cpp', 'Old') ])
    condition = SelectField('Condition', choices = [ ('cpp', 'Select'), ('cpp', 'New'), ('cpp', 'Used'), ('cpp', 'Old') ])
    submit = SubmitField('Upload Item')


#Route
@bp.route("/createProduct", methods=['GET', 'POST'])
def addProduct():
    form = createproduct()
    if form.validate_on_submit():
        flash('Successfully Uploaded Item', 'success')
        return redirect(url_for('addProduct'))
    return render_template("Addproduct.html", form=form)


#Model
'''
class Item(db.Model):
    __tablename__ = 'Product'
    name = db.Column(db.String(50))
    amount = db.Column(db.Integer(50))
    description = db.Column(db.String(50))
    length = db.Column(db.Integer(50))
    material = db.Column(db.String(50))
    gender = db.Column(db.String(50))
    condition = db.Column(db.String(50))

    def __repr__(self):
        return '<Item: name=%r, amount=%r, description=%r>, length=%r>, material=%r>, gender=%r>, condition=%r> ' %.format(self.name, self.amount, self.description, self.length, self.material, self.gender, self.condition)

'''

#Debugging 
if __name__ == "__main__":
    bp.run(debug=True)