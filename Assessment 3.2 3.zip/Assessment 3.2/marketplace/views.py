from flask import Blueprint, render_template, request, session


mainbp = Blueprint('main', __name__)

@mainbp.route('/') 
def index():
    return render_template('index.html')
