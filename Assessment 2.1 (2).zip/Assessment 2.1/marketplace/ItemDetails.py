from flask import Blueprint, render_template

bp = Blueprint('ItemDetail', __name__, url_prefix='/ItemDetails')

@bp.route('/<id>')
def show(id):
    return render_template('ItemDetails/show.html')