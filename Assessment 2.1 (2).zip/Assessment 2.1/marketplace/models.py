from . import db
from datetime import datetime
from flask_login import UserMixin
class Item:
    def __init__(self, name, description, image, cost, condition):
        self.name = name
        self.description = description
        self.image = image
        self.cost = cost
        self.condition = condition
        self.comments = list()

    def set_comments(self, comment):
            self.comments.append(comment)

class Comment:
    def __init__(self, user, text, created_at):
        self.user = user
        self.text = text
        self.created_at = created_at


        