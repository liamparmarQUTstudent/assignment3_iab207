from flask import Flask, render_template , url_for, flash, redirect, session
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, RadioField
from wtforms.validators import DataRequired, Length, EqualTo
from flask_sqlalchemy import SQLAlchemy


#Configuration
app = Flask (__name__)
app.config['SECRET_KEY'] = '12345'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SESSION_TYPE'] = 'filesystem'

db = SQLAlchemy(app)



class orderforum(FlaskForm):
    fullname = StringField('Fullname',validators=[DataRequired()])
    address = StringField('Address',validators=[DataRequired()])
    postcode = StringField('Postcode', validators=[DataRequired(),Length(min=4, max=5),EqualTo('postcode', message='Passwords must match')])

    submit = SubmitField('Confirm and Pay')


@app.route("/")
@app.route("/OrderPage", methods=['GET', 'POST'])
def orderr():
    form = orderforum()
    if form.validate_on_submit():
         flash('Successful Purchase! Order id: #35093783', 'success')
    return render_template("order.html", form=form)


'''
class orderforum(db.Model):
    fullname = db.Column("fullname", db.String(50), nullable=False)
    address = db.Column("address", db.String(50), nullable=False)
    postcode = db.Column("fullname", db.Integer, nullable=False)

    def __repr__(self):
        return "<orderform: {}>".formart(self.fullname, self.address, self.postcode)
'''

if __name__ == "__main__":
    app.run(debug=True)
