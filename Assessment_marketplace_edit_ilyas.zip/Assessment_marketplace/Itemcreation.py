from flask import Flask, render_template , url_for, flash, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length



app = Flask (__name__)
app.config['SECRET_KEY'] = '4321'



class createitem(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    amount = StringField('Amount',validators=[DataRequired(), Length(min=1, max=10)])
    description = StringField('Description', validators=[DataRequired()])
    length = StringField('Length', validators=[DataRequired()])
    material = StringField('Material', validators=[DataRequired()])
    gender = SelectField('Gender',choices = [ ('cpp', 'Select'), ('cpp', 'Female'), ('cpp', 'Male'), ('cpp', 'Unsexed') ])
    condition = SelectField('Condition', choices = [ ('cpp', 'Select'), ('cpp', 'New'), ('cpp', 'Used'), ('cpp', 'Old') ])
    
    submit = SubmitField('Upload Item')

class orderforum(db.Model):
    name = db.Column("Name", db.String(50), nullable=False)
    amount = db.Column("Amount", db.String(50), nullable=False)
    description = db.Column("Description", db.Integer, nullable=False)
    length = db.Column("Length", db.String(50), nullable=False)
    material = db.Column("Material", db.String(50), nullable=False)
    gender = db.Column("Gender", db.String(50), nullable=False)
    condition = db.Column("Condition", db.String(50), nullable=False)

    def __repr__(self):
        return "<createitem: {}>".formart(self.name)



@app.route("/")
@app.route("/Createitem", methods=['GET', 'POST'])
def item_creation():
    itemfourm = createitem()
    if itemfourm.validate_on_submit():
        flash('Successfully Uploaded Item', 'success')
    return render_template("creationofitem.html", itemfourm=itemfourm)



if __name__ == "__main__":
    app.run(debug=True)
