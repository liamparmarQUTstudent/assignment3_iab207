from flask import Flask 



def create_app():
    print(__name__)
    app=Flask(__name__)
    app.secret_key='hi'

    from . import views
    app.register_blueprint(views.mainbp)

    from . import ItemDetails
    app.register_blueprint(ItemDetails.bp)

    return app
