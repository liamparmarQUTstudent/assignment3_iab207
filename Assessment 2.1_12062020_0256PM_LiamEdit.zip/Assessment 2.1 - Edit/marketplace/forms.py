from flask_wtf import FlaskForm
from wtforms.fields import TextAreaField,SubmitField, StringField, PasswordField
from wtforms.validators import InputRequired, Length, Email, EqualTo

class LoginForm(FlaskForm):
    user_name=StringField("Username", validators=[
        InputRequired('Enter Username')])
    password = PasswordField("Password", validators=[
        InputRequired('Enter password')])
    submit = SubmitField("Login")

class RegisterForm(FlaskForm):
    user_name = StringField("Username", validators=[InputRequired()])
    email_id = StringField("Email Address", validators=[InputRequired()])
    password = PasswordField("Password", validators=[
        InputRequired(),
        EqualTo('confirm', message="Passwords should match")])
    confirm = PasswordField("Confirm Password")
    submit = SubmitField("Register")

class ItemForm(FlaskForm):
    name = StringField('Name', validators=[InputRequired()])
    description = TextAreaField('Description', validators=[InputRequired()])
    image = StringField('Cover Image', validators=[InputRequired()])
    cost = StringField('Cost', validators=[InputRequired()])
    stock = StringField('Quantity', validators=[InputRequired()])
    condition = StringField('Condition', validators=[InputRequired()])
    submit = SubmitField('Create')

class CommentForm(FlaskForm):
    text = TextAreaField('Comment', [InputRequired()])
    submit = SubmitField('Create')