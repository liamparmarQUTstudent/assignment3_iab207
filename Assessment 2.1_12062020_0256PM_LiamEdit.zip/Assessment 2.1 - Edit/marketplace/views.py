from flask import Blueprint, render_template, request, session


mainbp = Blueprint('main', __name__)

@mainbp.route('/') 
def index():
    return render_template('index.html')

#@mainbp.route('/login', methods=['GET','POST'])
#def login():
 #   print(request.values.get('email'))
  #  print(request.args.get('pwd'))
#
 #   print(request.form.get('email'))
    
  #  session['email']=request.values.get('email')
   # return render_template('login.html')

@mainbp.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return 'You have been logout'