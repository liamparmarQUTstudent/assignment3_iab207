from flask import Flask, redirect, url_for , render_template, request, redirect
from flask import blueprints

app = Flask (__name__)

@app.route('/Order', methods=['GET','POST'])
def order_page():

    if request.method == "POST":

        req = request.form

        fullname = req.form.get("fullname")
        address =  req.get("address")
        postcode = req.get("postcode")

        print(fullname, address, postcode)

        return redirect(request.url,)


    return render_template('Orderpage.html')

@app.route('/Item', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        print(request.form.getlist('exampleRadios'))



if __name__ == "__main__":
    app.run(debug=True)