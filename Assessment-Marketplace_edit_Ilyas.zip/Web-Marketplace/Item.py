from flask import Flask, redirect, url_for , render_template, request
from flask import blueprints



app = Flask (__name__)



@app.route('/Item', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        print(request.form.getlist('mycheckbox'))
    return render_template('itemDetail.html')

@app.route('/Order', methods=['GET','POST'])
def ord():
    return render_template('Orderpage.html')


#class Comment(db.Model):
 #   id = db.Column(db.Integer, primary_key=True)
 #   name = db.Column (db.String(50), unique=False)
 #   email = db.Column(db.String(120), unique=False, nullable=Flase)
 #   message = db.Column(db.Text, nullable=Flase)
 #   post_id = db.Column(db.Integer, db.ForeignKey ('post.id'), nullable=Flase)
 #   post = db.relationship('Post',backref=db.backref('post',lazy=True))
 #   pub_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
 #   status = db.Column(db.Boolean, default=False)


#def __repr__(self):
   # return '<comment %r>' % self.username

if __name__ == "__main__":
    app.run(debug=True)