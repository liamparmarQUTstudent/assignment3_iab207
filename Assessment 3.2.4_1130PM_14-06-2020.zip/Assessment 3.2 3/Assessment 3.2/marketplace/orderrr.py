from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required
from .models import Item, Comment
from .forms import ItemForm, CommentForm
from. import db

# # create blueprint
# bp = Blueprint('ItemDetails', __name__, url_prefix='/ItemDetails')

# @bp.route('/<id>')
# def show(id):
#     item = get_item()
#     item = Item.query.filter_by(id=id).first()
#     cform = CommentForm()
#     return render_template('ItemDetails/show.html', item=item)

# @bp.route('create',methods=['GET','POST'])
# @login_required   
# def create():                                    
#    print('Method type: ', request.method)
#     form = ItemForm()
#    if form.validate_on_submit():
#    item = Item(name=form,name.data,
#       description = form.description.data,
#       image = form.image.data,
#       cost = form.cost.data,
#       stock = form.stock.data,
#       condition = form.condition,data)
  
#   db.session.add(item)
#   db.session,commit()
#   print ('Successfully Purchased new item', 'success')
#   return redirect(url_for('item.create'))

#    return render_template('ItemDetails/OrderPage.html', form=form)