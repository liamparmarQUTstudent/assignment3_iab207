from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required
from .models import Item, Comment
from .forms import ItemForm, CommentForm

# create blueprint
bp = Blueprint('ItemDetail', __name__, url_prefix='/ItemDetails')

@bp.route('/<id>')
def show(id):
    #item = get_item()
    item = Item.query.filter_by(id=id).first()
    cform = CommentForm()
    return render_template('ItemDetails/show.html', item=item, form=cform)

#@bp.route('create',methods=['GET','POST'])  <--- Ilyas, I commented this out but this for the creation of your item, so change directory if needed
#def create():                                    to whatever your add item html is lol, sorry for writing this long or if this don't make sense probs LMAOOO
#    print('Method type: ', request.method)
#   form = ItemForm()
#    if form.validate_on_submit()
#    item = Item(name=form,name.data,
#       description = form.description.data,
#       image = form.image.data,
#       cost = form.cost.data,
#       stock = form.stock.data,
#       condition = form.condition,data)
#   
#   db.session.add(item)
#   db.session,commit()
#   print ('Successfully created new item', 'success')
#   return redirect(url_for('item.create'))

#    return render_template('ItemDetails/create_item.html', form=form)

##############   USE THIS CODE TEMPORARILY - PRE CHECK BEFORE DATABASE ######################
def get_item():
    # creating the description
    lv_desc = """Slender by name, slender by nature. This wallet in masculine Monogram 
    Eclipse canvas is suitably compact and slim, will carry all the essentials and still 
    fit into a front or back pocket with ease.(Louis Vuitton)"""
    # an image location
    image_loc = 'img/WalletItem2.jpg'
    item = Item('Louis Vuitton', lv_desc, image_loc, 'Price: AU $300', 'More than 10 avaliable', 'BRAND NEW')
    
    # a comment

    comment = Comment(
        "User1", "Great Wallet", '2019-11-12 11:00:00')
    comment2 = Comment(
        "User2", "Great Wallet, would recommend. Fast Delivery. Got it last Monday and has been my favorite wallet.", '2019-11-13 11:00:00')

    item.set_comments(comment)
    item.set_comments(comment2)

    return item