from flask import Blueprint, render_template, request, session
from .forms import LoginForm, RegisterForm

bp = Blueprint('auth', __name__)
@bp.route('/login', methods=['GET','POST'])
def login():
    loginForm = LoginForm()
    return render_template('user.html', form=loginForm,
    heading='Login')

@bp.route('/register', methods=['GET','POST'])
def register():
    register = RegisterForm()
    return render_template('user.html', form=register,
    heading='Register')